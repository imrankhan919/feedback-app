const Reviews = [
    {id : 1 , rating : 8 , text : "Some Good Review Here.."},
    {id : 2 , rating : 7 , text : "Average Product With Good Price"},
    {id : 3 , rating : 9 , text : "Good Product With Average Price"},
    {id : 4 , rating : 10 , text : "Good Product With Average Price"},
    {id : 5 , rating : 6 , text : "Good Product With Average Price"},
  ] 

  export default Reviews